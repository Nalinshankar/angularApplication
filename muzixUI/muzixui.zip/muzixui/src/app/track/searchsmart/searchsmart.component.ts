import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchsmart',
  templateUrl: './searchsmart.component.html',
  styleUrls: ['./searchsmart.component.css']
})
export class SearchsmartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
