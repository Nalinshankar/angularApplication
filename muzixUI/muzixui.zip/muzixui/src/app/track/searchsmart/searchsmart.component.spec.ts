import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchsmartComponent } from './searchsmart.component';

describe('SearchsmartComponent', () => {
  let component: SearchsmartComponent;
  let fixture: ComponentFixture<SearchsmartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchsmartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchsmartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
