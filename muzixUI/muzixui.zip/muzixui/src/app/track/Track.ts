export class Track {
    trackId: string;
    trackName: string;
    trackComment: string;
}
