export class Image {
    imageId: string;
    imageName: string;
    imageUrl: string;
}
